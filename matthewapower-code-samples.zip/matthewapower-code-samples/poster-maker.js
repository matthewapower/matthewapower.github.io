import loadImage from './loadImage';

var sketch = function (p) {
  var $img;
  var bg;
  var placeholder;
  var input;
  var button;
  var textInput;
  var userText;
  var canvasWidth;
  var canvasHeight;
  var canvasScale;
  var canvasState = {
    dirty: false,
    currentPoster: 0,
    drawing: true,
  }

  // set up variables and information for multiple posters.
  var posters = [
    {
      colorPrimary: '#df343c',
      colorSecondary: '#ececec',
      duotone: '#df343c, #ececec',
      bgImagePath: 'images/template.png',
      uploadAreaX: 189,
      uploadAreaY: 71,
      uploadAreaSize: 360,
    },
    {
      colorPrimary: '#edeed5',
      colorSecondary: '#c62037',
      duotone: '#c62037, #edeed5',
      bgImagePath: 'images/poster-maker-bg-2.png',
      uploadAreaX: 35,
      uploadAreaY: 80,
      uploadAreaSize: 325,
    },
    {
      colorPrimary: '#c32037',
      colorSecondary: '#212120',
      duotone: '#212120, #c32037',
      bgImagePath: 'images/template-03.png',
      uploadAreaX: 189,
      uploadAreaY: 117,
      uploadAreaSize: 423,
    },
    {
      colorPrimary: '#c32037',
      colorSecondary: '#e0e0e0',
      duotone: '#c32037, #e0e0e0',
      bgImagePath: 'images/template-04.png',
      uploadAreaX: 200,
      uploadAreaY: 340,
      uploadAreaSize: 390,
    },
    {
      colorPrimary: '#c32037',
      colorSecondary: '#212120',
      duotone: '#212120, #c32037',
      bgImagePath: 'images/template-05.png',
      uploadAreaX: 304,
      uploadAreaY: 451,
      uploadAreaSize: 286,
    },
    {
      colorPrimary: '#212120',
      colorSecondary: '#c32037',
      duotone: '#212120, #c32037',
      bgImagePath: 'images/template-06.png',
      uploadAreaX: 96,
      uploadAreaY: 158,
      uploadAreaSize: 424,
    },
  ]

  p.setup = function () {
    var c = p.createCanvas(612, 792);
    const {uploadAreaX,uploadAreaY,uploadAreaSize} = posters[canvasState.currentPoster]

    if (/Android|webOS|iPhone|iPad|iPod|BlackBerry/i.test(navigator.userAgent)) {
      canvasWidth = $(window).width() * 0.9;
      canvasHeight = canvasWidth * 1.294;
      canvasScale = canvasWidth / 612;
      c = p.createCanvas(canvasWidth, canvasHeight);
      $('canvas').css({ width: '90vw', height: canvasHeight + 'px' });
      placeholder = p.loadImage('images/placeholder-upload.jpg', function (placeholder) {
        p.image(placeholder, uploadAreaX * canvasScale, uploadAreaY * canvasScale, uploadAreaSize * canvasScale, uploadAreaSize * canvasScale);
      });

      bg = p.loadImage(posters[canvasState.currentPoster].bgImagePath, function (bg) {
        p.image(bg, 0, 0, canvasWidth, canvasHeight);
      });

      canvasState.drawing = false;
    } else {
      canvasWidth = 612;
      canvasHeight = 792;
      canvasScale = 1;
      placeholder = p.loadImage('images/placeholder-upload.jpg', function (placeholder) {
        p.image(placeholder, uploadAreaX, uploadAreaY, uploadAreaSize, uploadAreaSize);
      });

      bg = p.loadImage(posters[canvasState.currentPoster].bgImagePath, function (bg) {
        p.image(bg, 0, 0, 612, 792);
      });
    }
    c.addClass('droppable');
    c.parent('canvasWrapper');
    c.drop(gotFile);
    input = p.createFileInput(gotFile);
    input.addClass('clickable-input-target');
    input.parent('#canvasControls');
    textInput = p.createInput()
                 .addClass('text-input hide')
                 .parent('#addText');
    userText = false;
    p.background('#ececec');
    p.textSize(45);
  };

  function processImg(upload, callback) {
    $(function () {
      $(upload).duotone({ gradientMap: posters[canvasState.currentPoster].duotone });
      callback(upload);
    });
  }

  function addImg(upload) {
    $(function () {
      setTimeout(function () {
        var processedSrc;
        processedSrc = $(upload).attr('src');
        p.background('#ececec');
        p.loadImage(processedSrc, function (processedSrc) {
          var $img = $(upload);
          var imgWidth = $img.width();
          var imgHeight = $img.height();
          var aspectRatio = imgWidth / imgHeight;
          var imgSize = posters[canvasState.currentPoster].uploadAreaSize;
          var imgX = posters[canvasState.currentPoster].uploadAreaX;
          var imgY = posters[canvasState.currentPoster].uploadAreaY;
          if (imgWidth > imgHeight) {
            imgHeight = imgSize;
            imgWidth = imgSize * aspectRatio;
            imgX = imgX - ((imgWidth - imgSize) / 2);
            p.image(processedSrc, imgX * canvasScale, imgY * canvasScale, imgWidth * canvasScale, imgHeight * canvasScale);
          } else {
            imgWidth = imgSize;
            imgHeight = imgSize / aspectRatio;
            imgY = imgY - ((imgHeight - imgSize) / 2);
            p.image(processedSrc, imgX * canvasScale, imgY * canvasScale, imgWidth * canvasScale, imgHeight * canvasScale);
          }
        });

        if (/Android|webOS|iPhone|iPad|iPod|BlackBerry/i.test(navigator.userAgent)) {
          var width = $(window).width() * 0.9;
          var height = width * 1.294;
          bg = p.loadImage(posters[canvasState.currentPoster].bgImagePath, function (bg) {
            p.image(bg, 0, 0, width, height);
          });
        } else {
          bg = p.loadImage(posters[canvasState.currentPoster].bgImagePath, function (bg) {
            p.image(bg, 0, 0, 612, 792);
          });
        }

        // reset canvas state
        canvasState.dirty = false;
      }, 100);
    });
  }

  function gotFile(f) {
    if (f.type === 'image') {
      var size = f.size;
      var restructuredImage = loadImage(f.data, (canvas) => {
        let image = new Image();
        image.src = canvas.toDataURL('image/png');
        $img = p.createImg(image.src).addClass(size).hide();
        processImg('.' + size, addImg);
        $('.draggable').show();
      },{
        orientation: true,
        canvas: false,
      })
    } else {
      print(`"${f.name}" isn't an image file!`);
    }
  }

  p.mouseDragged = function () {
    if (userText === false && $('.ui-draggable').hasClass('ui-draggable-dragging') === false) {
      p.strokeWeight(5);
      p.stroke(posters[canvasState.currentPoster].colorPrimary);
      p.line(p.mouseX, p.mouseY, p.pmouseX, p.pmouseY);

      // canvas has been drawn on
      canvasState.dirty = true;
    }
  };

  p.mouseMoved = function (e) {
    if ($(textInput).hasClass('hidden') === false) {
      textInput.position(e.pageX, e.pageY);
    }
  };

  p.mousePressed = function () {
    if (userText !== false) {
      p.noStroke();
      p.textFont('monospace', 40);
      p.fill(posters[canvasState.currentPoster].colorPrimary);
      p.text(textInput.value(), p.mouseX, p.mouseY);
      userText = false;
      //text has been added
      canvasState.dirty = true;
    }

    if (!/Android|webOS|iPhone|iPad|iPod|BlackBerry/i.test(navigator.userAgent)) {
      $('.text-input').addClass('hide').select();
    }
  };

  function addText() {
    p.noStroke();
    userText = textInput.value();
    canvasState.dirty = true;
  }

  function makeid() {
    var text = '';
    var possible = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';

    for (var i = 0; i < 5; i++)
      text += possible.charAt(Math.floor(Math.random() * possible.length));

    return text;
  }

  p.keyPressed = function () {
    addText();
  };

  $(function () {
    $('#canvasWrapper').droppable({
      drop: function (event, ui) {
        let ok = true;
        if (canvasState.dirty) ok = window.confirm('Are you sure? You will lose your drawings and text.');
        if (ok) {         
          var picId = makeid();
          var imgUrl = $(ui.draggable)
            .css('background-image').replace('url("', '').replace('")', '');
          var newImg = p.createImg(imgUrl).addClass(picId).hide();

          $('.draggable').show();
          $(ui.draggable).hide();
          processImg('.' + picId, addImg);
        }
      },
    });
  });

  $('.mobile-pic').click(function () {
    $('.mobile-image-folder__window').removeClass('open');
    let ok = true;
    if (canvasState.dirty) ok = window.confirm('Are you sure? You will lose your drawings and text.');
    if (ok) {
      var picId = makeid();
      var newImg = p.createImg($(this).attr('src')).addClass(picId).hide();
      processImg('.' + picId, addImg);
    }
  });

  // Map icon click to input click
  $('.uploadImg').click((e) => {
    $('.clickable-input-target').click();
  });

  $('#switchPoster').click(() => {
    if (posters.length - 1 === canvasState.currentPoster) {
      canvasState.currentPoster = 0;
    } else {
      canvasState.currentPoster++
    }
    p.setup()
  })

  $('#openImageDrawer').click(() => {
    $('.mobile-image-folder__window').addClass('open');
  });

  $('#drawMobile').click(() => {
    canvasState.drawing = !canvasState.drawing
  })

  if (/Android|webOS|iPhone|iPad|iPod|BlackBerry/i.test(navigator.userAgent)) {
    $('.text-input').draggable();
  }

  $('.close-saveImageModal').click(() => {
    $('#saveImageModal').removeClass('open');
    $('.image-remove').remove();
  });

  $('#addText').click(function (e) {
    addText();
    if (/Android|webOS|iPhone|iPad|iPod|BlackBerry/i.test(navigator.userAgent)) {
      $('.text-input').draggable();
    } else {
      textInput.position(e.pageX, e.pageY);
    }

    $('.text-input').removeClass('hide').select();
  });

  $('#savePoster').click(function (e) {
    e.preventDefault();
    if (/Android|webOS|iPhone|iPad|iPod|BlackBerry/i.test(navigator.userAgent)) {
      var $canvas = $('canvas');
      $('#saveImageModal').addClass('open')
      var savedImg = p.createImg($canvas[0].toDataURL('png'))
                      .addClass('image-remove')
                      .parent('#saveImageModal')
    } else {
      p.saveCanvas('Freedom-Fighter-Poster');
    }
  });

  var ptouchX, ptouchY;

  p.touchMoved = function (e) {
    var $c = $('canvas');
    var touchX = e.touches['0'].pageX;
    var touchY = e.touches['0'].pageY;
    var canvasWindow = {
      top: $c.position().top,
      left: $c.position().left,
      right: $c.position().left + $c.width(),
      bottom: $c.position().top + $c.height(),
    };

    if (touchX > canvasWindow.left &&
        touchX < canvasWindow.right &&
        touchY > canvasWindow.top &&
        touchY < canvasWindow.bottom &&
        canvasState.drawing) {
      // var $doc = $(document);
      // var scaleX = $doc.width() / $c.width();
      var canvasX = touchX - canvasWindow.left;
      var canvasY = touchY - canvasWindow.top;
      p.strokeWeight(3);
      p.stroke(posters[canvasState.currentPoster].colorPrimary);
      p.line(canvasX, canvasY, ptouchX || canvasX, ptouchY || canvasY);
      ptouchX = canvasX;
      ptouchY = canvasY;
      canvasState.dirty = true;
    }

    $('.text-input').css({ left: e.touches['0'].pageX, top: e.touches['0'].pageY });
  };

  p.touchEnded = function (e) {
    ptouchX = null;
    ptouchY = null;
  };

  let blockMenuHeaderScroll = false;

  $(window).on('touchstart', function(e) {
    if ($(e.target).closest('#canvasWrapper').length == 1) {
      blockMenuHeaderScroll = true;
    }
  });

  $(window).on('touchend', function() {
    blockMenuHeaderScroll = false;
  });

  $(window).on('touchmove', function(e) {
    if (blockMenuHeaderScroll) {
      e.preventDefault();
    }
  });
};

if ($('body').hasClass('sketch')) {
  new p5(sketch);
}
